﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dataIOtest
{
    class Database
    {
        private MySqlConnection conn;
        private Form1 form;
        private Form2 f2;
       
        public Database(Form2 f2)
        {
            this.f2 = (Form2)f2;

            conn = new MySqlConnection();
            string server = "192.168.3.36";
            string uid = "root";
            string password = "1234";
            string database = "test";
            conn.ConnectionString = string.Format("server={0};uid={1};password={2};database={3}", server, uid, password, database);
            try
            {
                conn.Open();
            }
            catch
            {
                MessageBox.Show("DB 오류");
            }
        }
        
        public Database(Form1 form)
        {
            this.form = (Form1)form;
            
            conn = new MySqlConnection();
            string server = "192.168.3.36";
            string uid = "root";
            string password = "1234";
            string database = "test";
            conn.ConnectionString = string.Format("server={0};uid={1};password={2};database={3}", server, uid, password, database);
            try
            {
                conn.Open();
            }
            catch
            {
                MessageBox.Show("DB 오류");
            }
        }

        public void R()
        {
            try
            {
                MySqlCommand comm = new MySqlCommand("sp_select", conn);
                comm.CommandType = CommandType.StoredProcedure;
                MySqlDataReader sdr = comm.ExecuteReader();
                form.listView1.Items.Clear();
                while (sdr.Read())
                {
                    string[] arr = new string[sdr.FieldCount];
                    for (int i = 0; i < sdr.FieldCount; i++)
                    {
                        arr[i] = sdr.GetValue(i).ToString();
                    }
                    form.listView1.Items.Add(new ListViewItem(arr));
                }
                sdr.Close();
            }
            
            catch//MySqlException 오류 내용 가져올때 
            {
                
            }
        }

        public void CUD(string commandText, bool key1, bool key2, string no) // 추가(name,age)/수정(no,name,age)/삭제(no)
        {
            try
            {
                MySqlCommand comm = new MySqlCommand(commandText, conn);
                comm.CommandType = CommandType.StoredProcedure;

                if (key1)
                {
                    comm.Parameters.AddWithValue("_No", no);
                }
                if (key2)
                {
                    string title = f2.textBox1.Text;
                    string desc = f2.textBox2.Text;
                    string pre = f2.textBox3.Text;
                    string password = f2.textBox4.Text;

                    comm.Parameters.AddWithValue("_Ltitle", title);
                    comm.Parameters.AddWithValue("_LDesc", desc);
                    comm.Parameters.AddWithValue("_LPre", pre);
                    comm.Parameters.AddWithValue("_Lpassword", password);
                }
                comm.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("성공적으로 완료 되었습니다.");
            }

            catch
            {
                MessageBox.Show("오류");
            }

            R();
        }
    }
}
